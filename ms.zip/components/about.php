<section class="about container">
  <h2 class="section-title">Привет, <?= $name ?></h2>
  <img class="about-image" src="<?= $image ?>" width="147" height="147" alt="<?= $name ?>">
  <div class="about-content">
    <p>Для нормального человека одна бутылка пива в самый раз, две - много, три - мало! </p>
    <p>Жизнь — это рюкзак нагруженный пивом. Чем больше пива ты пьешь, тем легче</p>
    <p>Если пиво ты не любишь, значит жизнь свою ты губишь
  </div>
</section>

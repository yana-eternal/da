<section class="photos container">
  <h2 class="section-title">МЕМЫ</h2>
  <figure>
    <img src="img/з.jpg" width="285" height="146">
  </figure>
  <figure>
    <img src="img/з1.jpg" width="285" height="146">
  </figure>
  <figure>
    <img src="img/з2.jpg" width="285" height="146">
  </figure>
  <figure>
    <img src="img/з3.jpg" width="285" height="146">
  </figure>
</section>

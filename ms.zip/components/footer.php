</main>
  <footer class="page-footer">
    <div class="container">
      <p>© <?= $name ?></p>
      <p>2022</p>
    </div>
  </footer>
  <script src="script.js"></script>
</body>
</html>

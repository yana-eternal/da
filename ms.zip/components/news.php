<section class="news container">
  <h2 class="section-title">Новости с завода</h2>
  <article class="card">
    <img src="img/biceps.svg" width="56" height="56" alt="HTML">
    <div class="card-content">
      <h3>Начал проходить курсы HTML Academy</h3>
      <p>Оказалось, что вёрстка - это не сложно и очень интересно!</p>
      <time datetime="2020-08-03">3 августа 2022</time>
    </div>
  </article>
  <article class="card">
    <img src="img/keks-bane.svg" width="56" height="56" alt="HTML">
    <div class="card-content">
      <h3>сорвала спину</h3>
      <p>обожаю таблетки</p>
      <time datetime="2020-08-04">20 марта 2022</time>
    </div>
  </article>
  <article class="card">
    <img src="img/treasure-map.svg" width="56" height="56" alt="HTML">
    <div class="card-content">
      <h3>мою посуду 8 часов</h3>
      <p>водой спиртом снова водой</p>
      <time datetime="2020-08-05">16 марта 2022</time>
    </div>
  </article>
</section>

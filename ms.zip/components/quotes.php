<section class="quotes container">
  <h2 class="section-title">Любимые цитаты</h2>
  <blockquote>
    <p>я волк ауф</p>
    <cite>волк</cite>
  </blockquote>
</section>

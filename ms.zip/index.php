<?php
$title = 'хто ты';
$name = 'хто я';
$image = 'img/img1.jpg';
$email = 'ya_vam_ne_skazhu@gmail.com';
$phone = '8-800-555-35-35';

require('components/header.php');
require('components/about.php');
require('components/status.php');
require('components/photos.php');
require('components/news.php');
require('components/quotes.php');
require('components/contacts.php');
require('components/footer.php');
